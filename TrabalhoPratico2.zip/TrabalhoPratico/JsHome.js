
function CarregarCards() {
  fetch('https://diwserver.vps.webdock.cloud/products')
  .then(res => res.json())
  .then(data => {
    let article = document.querySelector('.cards')
    data.products.forEach(element => {
        article.innerHTML += `<div name = 'produtos' id = '${element.id}'>
        <img src="${element.image}" alt="">
        <h5><a href = "./detalhes.html?id=${element.id}">${element.title} </a></h5>
        <p>Preço: R$${element.price}</p>
        <p class="categoria">Categoria: ${element.category}</p>
        <p>Nota dos usuários: ${element.rating.rate}
      </div>`
    })
  })
}

window.onload = CarregarCards()


function pesquisar() {
  var texto = document.getElementById('pesquisa1').value
  var textofiltro = document.getElementById('textofiltro')
  if (texto.length > 0) {
      textofiltro.style.display = "block"
      textofiltro.textContent = 'Filtrado por ' + texto
      limpa()
      
      var card = document.getElementsByName('produtos')
      cont = 0
      for(var i = 0; i < card.length;i++){
        var prod = card[i]
        prod.style.display = 'inline-block'
        var conteudo = prod.textContent
        var conteudo = conteudo.toLowerCase()
        var texto = texto.toLowerCase()
        if(!conteudo.includes(texto)){
          prod.style.display = 'none'
          cont++
      }
      if (cont == 20){
          alert("Produto não encontrado")
      }
  }
       
  }else{
    textofiltro.style.display = "none"
    alert('Digite algo antes de pesquisar')
  }
} 

function criacat(){
fetch('https://diwserver.vps.webdock.cloud/products')
.then(res => res.json())
.then(data => {
  var select = document.getElementById('filtrocat')
  let categoria = []
  data.products.forEach(element =>{
    if(!categoria.includes(element.category)){
      categoria.push(element.category)
      } 
  })
  for(i = 0;i<categoria.length;i++){
    let option = document.createElement('option')
    option.className = 'opcao'
    option.textContent = categoria[i]
    select.appendChild(option)
    }
})
}

window.onload = criacat()


function filtrocat() {
  var select = document.getElementById('filtrocat')
  var cards = document.getElementsByName('produtos')
  var categorias = document.getElementsByClassName('categoria')
  var textofiltro = document.getElementById('textofiltro')

  for (i = 0; i < categorias.length; i++) {
    var categoria = categorias[i]
    var card = cards[i]
    card.style.display = 'inline-block'
    textofiltro.style.display = 'none'
    var textocategoria = categoria.textContent;
    var opcao = select.selectedOptions[0]
    var textopcao = opcao.textContent

    if (!textocategoria.includes(textopcao)) {
      card.style.display = 'none'
    }
  }
}

function limpa(){
    const pesquisa = document.getElementById('pesquisa1')
    pesquisa.value = ''
}



