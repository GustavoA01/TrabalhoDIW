
window.onload = () =>{
    let param = window.location.href
    let x = param.split('=')[1]
    var url = `https://diwserver.vps.webdock.cloud/products/${x}`
    fetch(url)
    .then(res=>res.json())
    .then(element => {
        let sec = document.getElementById('produto')
        sec.innerHTML = 
        `<img src="${element.image}" alt="" id="imagem">
        <h3 id="nome">${element.title}</h3>
        <p id="descricao"><strong>Descrição:</strong> ${element.description}</p>
        <p id="preco"><strong>Preço:</strong> R$${element.price}</p>
        <p id = "categoria"><strong>Categoria: </strong> ${element.category}
        <p id="nota"><strong>Nota dos usuários:</strong> ${element.rating.rate}</p>`
    })
}

let home = () =>{
window.location.href = "TrabalhoPratico.html"
}
